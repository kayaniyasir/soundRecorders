package sa.edu.psu.recordapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;

public class Record extends AppCompatActivity {
    private ImageView record;
    private Button play, stop;
    private MediaRecorder recordAudio;
    private String output;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        record = findViewById(R.id.ivMicrophone);
        play = findViewById(R.id.btnPlay);
        stop = findViewById(R.id.btnStop);
        play.setEnabled(false);
        stop.setEnabled(false);

        output = getExternalCacheDir().getAbsolutePath() + "/recording.3gp";

        recordAudio = new MediaRecorder();
        recordAudio.setAudioSource(MediaRecorder.AudioSource.MIC);
        recordAudio.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recordAudio.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        recordAudio.setOutputFile(output);



        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    recordAudio.prepare();
                    recordAudio.start();
                } catch (IOException e) {
                    Log.e("test", e.getMessage() );
                }


                record.setEnabled(false);
                stop.setEnabled(true);

                Toast.makeText(Record.this, "Now Recording...", Toast.LENGTH_SHORT).show();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recordAudio.stop();
                recordAudio.release();
                recordAudio = null;
                record.setEnabled(true);
                stop.setEnabled(false);
                play.setEnabled(true);
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MediaPlayer playbackAudio = new MediaPlayer();
                try {
                    playbackAudio.setDataSource(output);
                    playbackAudio.prepare();
                    playbackAudio.start();
                } catch (Exception e) {

                }
            }
        });
    }
}
